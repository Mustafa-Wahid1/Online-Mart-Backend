'use strict';

const contactService = require('../services/contact.service');
const { success } = require('../utils/response');

const create = async (req, res, next) => {
  try {
    const data = await contactService.createContact(req.body);
    return success(res, data, 201);
  } catch (err) {
    next(err);
  }
};

module.exports = {
  create,
};
