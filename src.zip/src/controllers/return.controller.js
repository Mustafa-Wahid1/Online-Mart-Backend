'use strict';

const returnService = require('../services/return.service');
const { success } = require('../utils/response');

const listEligible = async (req, res, next) => {
  try {
    const data = await returnService.listEligibleOrders(req.user.id);
    return success(res, data);
  } catch (err) {
    next(err);
  }
};

const create = async (req, res, next) => {
  try {
    const data = await returnService.createReturn(req.user.id, req.body);
    return success(res, data, 201);
  } catch (err) {
    next(err);
  }
};

const listMine = async (req, res, next) => {
  try {
    const data = await returnService.listMine(req.user.id);
    return success(res, data);
  } catch (err) {
    next(err);
  }
};

const getMineById = async (req, res, next) => {
  try {
    const data = await returnService.getMineById(req.user.id, req.params.id);
    return success(res, data);
  } catch (err) {
    next(err);
  }
};

module.exports = {
  listEligible,
  create,
  listMine,
  getMineById,
};
