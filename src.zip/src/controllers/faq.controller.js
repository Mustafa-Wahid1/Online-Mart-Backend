'use strict';

const faqService = require('../services/faq.service');
const { success } = require('../utils/response');

const list = async (req, res, next) => {
  try {
    const data = await faqService.listFaqs(req.query);
    return success(res, data);
  } catch (err) {
    next(err);
  }
};

module.exports = {
  list,
};
