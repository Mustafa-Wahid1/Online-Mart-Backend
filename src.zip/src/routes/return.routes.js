'use strict';

const express = require('express');
const { body, param } = require('express-validator');
const router = express.Router();
const returnController = require('../controllers/return.controller');
const validate = require('../middlewares/validate.middleware');

router.get('/eligible', returnController.listEligible);

router.get('/my', returnController.listMine);

router.get(
  '/:id',
  [param('id').isMongoId().withMessage('Invalid return id')],
  validate,
  returnController.getMineById
);

router.post(
  '/',
  [
    body('orderId').isMongoId().withMessage('Valid order is required'),
    body('reason')
      .isIn(['DAMAGED', 'WRONG_ITEM', 'NOT_AS_DESCRIBED', 'QUALITY_ISSUE', 'CHANGED_MIND', 'OTHER'])
      .withMessage('Valid reason is required'),
    body('comments').optional({ nullable: true, checkFalsy: true }).isString().trim().isLength({ max: 2000 }),
    body('itemProductIds')
      .isArray({ min: 1 })
      .withMessage('Select at least one item to return'),
    body('itemProductIds.*').isMongoId().withMessage('Invalid product id'),
    body('images').optional().isArray({ max: 5 }),
    body('images.*').optional().isString().isLength({ max: 500 }),
  ],
  validate,
  returnController.create
);

module.exports = router;
