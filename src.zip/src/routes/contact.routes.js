'use strict';

const express = require('express');
const { body } = require('express-validator');
const router = express.Router();
const contactController = require('../controllers/contact.controller');
const validate = require('../middlewares/validate.middleware');
const { globalLimiter } = require('../middlewares/rateLimit.middleware');

router.post(
  '/',
  globalLimiter,
  [
    body('name')
      .trim()
      .notEmpty()
      .withMessage('Full name is required')
      .isLength({ max: 100 })
      .withMessage('Name is too long'),
    body('email').isEmail().withMessage('Valid email is required').normalizeEmail(),
    body('phone').optional({ nullable: true, checkFalsy: true }).isString().trim().isLength({ max: 30 }),
    body('subject')
      .trim()
      .notEmpty()
      .withMessage('Subject is required')
      .isLength({ max: 200 })
      .withMessage('Subject is too long'),
    body('message')
      .trim()
      .notEmpty()
      .withMessage('Message is required')
      .isLength({ max: 5000 })
      .withMessage('Message is too long'),
  ],
  validate,
  contactController.create
);

module.exports = router;
