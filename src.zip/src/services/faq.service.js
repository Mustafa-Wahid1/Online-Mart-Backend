'use strict';

const Faq = require('../models/Faq.model');

/**
 * List active FAQs grouped/sorted by category then order.
 */
const listFaqs = async (query = {}) => {
  const filter = { isActive: true };
  if (query.category) {
    filter.category = String(query.category).trim();
  }
  if (query.q) {
    const q = String(query.q).trim();
    if (q) {
      filter.$or = [
        { question: new RegExp(q, 'i') },
        { answer: new RegExp(q, 'i') },
      ];
    }
  }

  const rows = await Faq.find(filter).sort({ category: 1, order: 1, createdAt: 1 }).lean();

  return rows.map((f) => ({
    id: String(f._id),
    question: f.question,
    answer: f.answer,
    category: f.category,
    order: f.order,
  }));
};

module.exports = {
  listFaqs,
};
