'use strict';

const Contact = require('../models/Contact.model');
const AppError = require('../utils/AppError');
const env = require('../config/env');
const emailService = require('../infrastructure/email/email.service');
const logger = require('../utils/logger');

/**
 * Create a contact message and notify admin by email.
 */
const createContact = async (payload) => {
  const name = String(payload.name || '').trim();
  const email = String(payload.email || '').trim().toLowerCase();
  const phone = String(payload.phone || '').trim();
  const subject = String(payload.subject || '').trim();
  const message = String(payload.message || '').trim();

  if (!name) throw new AppError('Full name is required', 400, 'VALIDATION_ERROR');
  if (!email) throw new AppError('Email is required', 400, 'VALIDATION_ERROR');
  if (!subject) throw new AppError('Subject is required', 400, 'VALIDATION_ERROR');
  if (!message) throw new AppError('Message is required', 400, 'VALIDATION_ERROR');

  const doc = await Contact.create({
    name,
    email,
    phone,
    subject,
    message,
    status: 'NEW',
  });

  const adminTo = env.ADMIN_EMAIL || env.MAIL_FROM_EMAIL;
  if (adminTo) {
    const html = `
      <p><strong>New contact message</strong></p>
      <p><strong>From:</strong> ${escapeHtml(name)} &lt;${escapeHtml(email)}&gt;</p>
      ${phone ? `<p><strong>Phone:</strong> ${escapeHtml(phone)}</p>` : ''}
      <p><strong>Subject:</strong> ${escapeHtml(subject)}</p>
      <p><strong>Message:</strong></p>
      <p style="white-space:pre-wrap">${escapeHtml(message)}</p>
      <p style="color:#666;font-size:12px">ID: ${doc._id}</p>
    `;
    const result = await emailService.sendEmail({
      to: adminTo,
      toName: env.ADMIN_NAME || 'Admin',
      type: 'CONTACT_MESSAGE',
      subject: `[Contact] ${subject}`,
      html,
      text: `From: ${name} <${email}>\nPhone: ${phone}\nSubject: ${subject}\n\n${message}`,
    });
    if (result.status !== 'SENT' && result.status !== 'NOT_CONFIGURED') {
      logger.warn({ status: result.status, contactId: String(doc._id) }, 'Contact admin email not sent');
    }
  }

  return {
    id: String(doc._id),
    name: doc.name,
    email: doc.email,
    subject: doc.subject,
    status: doc.status,
    createdAt: doc.createdAt,
  };
};

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

module.exports = {
  createContact,
};
