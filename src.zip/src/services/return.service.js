'use strict';

const ReturnRequest = require('../models/Return.model');
const Order = require('../models/Order.model');
const AppError = require('../utils/AppError');
const { toString: moneyToString } = require('../utils/money');

/** Return window in days after delivery. */
const RETURN_WINDOW_DAYS = 14;

const REASON_LABELS = {
  DAMAGED: 'Item arrived damaged',
  WRONG_ITEM: 'Wrong item received',
  NOT_AS_DESCRIBED: 'Not as described',
  QUALITY_ISSUE: 'Quality issue',
  CHANGED_MIND: 'Changed my mind',
  OTHER: 'Other',
};

function formatReturn(doc) {
  const o = doc.toObject ? doc.toObject() : doc;
  return {
    id: String(o._id),
    orderId: String(o.orderId),
    orderNumber: o.orderNumber,
    userId: String(o.userId),
    items: (o.items || []).map((i) => ({
      productId: String(i.productId),
      name: i.name,
      sku: i.sku || '',
      quantity: i.quantity,
      unitPrice: moneyToString(i.unitPrice),
      imageUrl: i.imageUrl || '',
    })),
    reason: o.reason,
    reasonLabel: REASON_LABELS[o.reason] || o.reason,
    comments: o.comments || '',
    images: o.images || [],
    status: o.status,
    adminNotes: o.adminNotes || '',
    createdAt: o.createdAt,
    updatedAt: o.updatedAt,
  };
}

/**
 * Eligible delivered orders for the user within the return window.
 */
const listEligibleOrders = async (userId) => {
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - RETURN_WINDOW_DAYS);

  const orders = await Order.find({
    userId,
    status: 'DELIVERED',
    updatedAt: { $gte: cutoff },
  })
    .sort({ updatedAt: -1 })
    .lean();

  // Exclude orders that already have a non-rejected return
  const orderIds = orders.map((o) => o._id);
  const existing = await ReturnRequest.find({
    orderId: { $in: orderIds },
    status: { $ne: 'REJECTED' },
  })
    .select('orderId')
    .lean();
  const blocked = new Set(existing.map((r) => String(r.orderId)));

  return orders
    .filter((o) => !blocked.has(String(o._id)))
    .map((o) => ({
      id: String(o._id),
      orderNumber: o.orderNumber,
      status: o.status,
      total: moneyToString(o.total),
      deliveredAt: o.updatedAt,
      items: (o.items || []).map((i) => ({
        productId: String(i.productId),
        name: i.name,
        sku: i.sku || '',
        quantity: i.quantity,
        unitPrice: moneyToString(i.unitPrice),
        imageUrl: i.imageUrl || '',
      })),
    }));
};

/**
 * Create a return request.
 */
const createReturn = async (userId, payload) => {
  const orderId = payload.orderId;
  const reason = payload.reason;
  const comments = String(payload.comments || '').trim();
  const images = Array.isArray(payload.images) ? payload.images.filter(Boolean).slice(0, 5) : [];
  const itemProductIds = Array.isArray(payload.itemProductIds)
    ? payload.itemProductIds.map(String)
    : [];

  if (!orderId) throw new AppError('Order is required', 400, 'VALIDATION_ERROR');
  if (!reason || !REASON_LABELS[reason]) {
    throw new AppError('Valid reason is required', 400, 'VALIDATION_ERROR');
  }
  if (!itemProductIds.length) {
    throw new AppError('Select at least one item to return', 400, 'VALIDATION_ERROR');
  }

  const order = await Order.findOne({ _id: orderId, userId });
  if (!order) throw new AppError('Order not found', 404);

  if (order.status !== 'DELIVERED') {
    throw new AppError('Only delivered orders can be returned', 400, 'ORDER_NOT_ELIGIBLE');
  }

  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - RETURN_WINDOW_DAYS);
  const deliveredAt = order.updatedAt || order.createdAt;
  if (deliveredAt < cutoff) {
    throw new AppError(
      `Returns must be requested within ${RETURN_WINDOW_DAYS} days of delivery`,
      400,
      'RETURN_WINDOW_EXPIRED'
    );
  }

  const existing = await ReturnRequest.findOne({
    orderId: order._id,
    userId,
    status: { $ne: 'REJECTED' },
  });
  if (existing) {
    throw new AppError('A return request already exists for this order', 400, 'RETURN_EXISTS');
  }

  const selected = order.items.filter((i) => itemProductIds.includes(String(i.productId)));
  if (!selected.length) {
    throw new AppError('Selected items do not belong to this order', 400, 'VALIDATION_ERROR');
  }

  const doc = await ReturnRequest.create({
    orderId: order._id,
    userId,
    orderNumber: order.orderNumber,
    items: selected.map((i) => ({
      productId: i.productId,
      name: i.name,
      sku: i.sku || '',
      quantity: i.quantity,
      unitPrice: i.unitPrice,
      imageUrl: i.imageUrl || '',
    })),
    reason,
    comments,
    images,
    status: 'PENDING',
  });

  return formatReturn(doc);
};

const listMine = async (userId) => {
  const rows = await ReturnRequest.find({ userId }).sort({ createdAt: -1 });
  return rows.map(formatReturn);
};

const getMineById = async (userId, id) => {
  const doc = await ReturnRequest.findOne({ _id: id, userId });
  if (!doc) throw new AppError('Return request not found', 404);
  return formatReturn(doc);
};

module.exports = {
  listEligibleOrders,
  createReturn,
  listMine,
  getMineById,
  REASON_LABELS,
  RETURN_WINDOW_DAYS,
};
